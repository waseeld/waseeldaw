## Youtube Downloader

This Project was used in one of my stories on Medium. If there is any issues please open a new issue.

```
    cd Server
    npm install
    npm run dev 
```
